package simpledb;

public class Table {
	private DbFile file;
	private String tableName;
	private String pkeyField;


	public Table (DbFile file, String tableName, String pkeyField){
		this.file = file;
		this.tableName = tableName;
		this.pkeyField = pkeyField;

	}

	public DbFile getFile(){
		return file;
	}

	public String getTableName(){
		return tableName;
	}

	public String getPkeyField(){
		return pkeyField;
	}


	public boolean equals(Object o){
		if(o instanceof Table){
			Table other = (Table)o;
			if(this.tableName.equals(other.tableName)){
				return true;
			}
			else{
				return false;
			}
		}
		return false;
	}

	public int hashCode(){
		return file.hashCode() + tableName.hashCode() + pkeyField.hashCode();
	}
}